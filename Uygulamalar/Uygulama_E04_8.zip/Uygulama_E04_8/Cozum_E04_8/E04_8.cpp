﻿// E04_8.cpp : Bu dosya 'main' işlevi içeriyor. Program yürütme orada başlayıp biter.
//
#define _CRT_SECURE_NO_WARNINGS 1

#include <iostream>
#include <cstring>

class IzuKatar {
private:
    size_t m_boyut;        // Katarın uzunluğu sekizli cinsinden
    char* m_icerik;        // Karakter dizisine işaretçi

public:
    // Kurucu
    IzuKatar(const char* inData) {
        std::cout << "Kurucu calisti" << std::endl;
        m_boyut = std::strlen(inData);
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, inData);
    }

    // Kopya Kurucu
    IzuKatar(const IzuKatar& other) {
        std::cout << "Kopya Kurucu calisti" << std::endl;
        m_boyut = other.m_boyut;
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, other.m_icerik);
    }

    // Yıkıcı
    ~IzuKatar() {
        std::cout << "Yikici calisti" << std::endl;
        delete[] m_icerik;
    }

    // İçeriği yazdırma
    void yazdir() const {
        std::cout << m_icerik << " Uzunluk: " << m_boyut << std::endl;
    }

    // İçeriği değiştirme
    void setIcerik(const char* yeniIcerik) {
        delete[] m_icerik;
        m_boyut = std::strlen(yeniIcerik);
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, yeniIcerik);
    }
};

int main() {
    IzuKatar k1("katar 1");
    std::cout << "k1 yazdiriliyor:" << std::endl;
    k1.yazdir();

    std::cout << "----------------------" << std::endl;
    IzuKatar k2 = k1;  // Kopya kurucu çağrıldı
    std::cout << "k2 yazdiriliyor:" << std::endl;
    k2.yazdir();

    std::cout << "----------------------" << std::endl;
    k1.setIcerik("Diger bir katar");
    std::cout << "k1 yazdiriliyor:" << std::endl;
    k1.yazdir();
    std::cout << "k2 yazdiriliyor:" << std::endl;
    k2.yazdir();

    std::cout << "----------------------" << std::endl;
    return 0;
}
