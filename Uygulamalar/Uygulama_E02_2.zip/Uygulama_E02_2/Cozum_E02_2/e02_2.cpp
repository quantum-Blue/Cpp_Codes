// e02_2.cpp
// Global ve yerel degiskenler
// Scope resolution operatörü ::

#include <iostream>			// C++20 öncesi giris ve çıkıs için header dosyası
//import <iostream>;            // C++20'den itibaren
//import std;                      // C++23'ten itibaren

double value1{ 3.14 }; // Global

int main() {
	int value1{ 10 };		// Dıssal yerel value1, global value1'i gizler
	int value2{ 20 };		// Dıssal yerel value2

	std::cout << "Global value1'in degeri = " << ::value1 << std::endl;
	std::cout << "Dissal yerel value1'in degeri = " << value1 << std::endl;
	std::cout << "Yerel value2'nin degeri = " << value2 << std::endl;
	::value1 = ::value1 + value1;	// Global value1 ile yerel value1'i topla
	std::cout << "Degistirilmis global value1'in degeri = " << ::value1 << std::endl;
	std::cout << "Dissal yerel value1'in degeri = " << value1 << std::endl;
	
	{ /* Yeni (iç) blok kapsamı burada baslar... */
		int value1{ 15 };			// Bu, dıssal value1'i gizleyen yeni bir degiskendir
		int value3{ 30 };			// İçsel yerel value3
		::value1 = ::value1 + 0.1;  // Global value1'i degistir
		std::cout << "\nIcsel yerel value1'in degeri = " << value1 << std::endl;
		std::cout << "Global value1'in degeri = " << ::value1 << std::endl;
		std::cout << "Yerel value2'nin degeri = " << value2 << std::endl;
	} /* ...ve burada biter. */

	value2++;  // Dıssal yerel value2'ye erisebiliriz
	std::cout << "Yerel value2'nin degeri = " << value2 << std::endl;	
	//value3++;  Artık içsel yerel bir degiskene erisemezsiniz.
	return 0;
}