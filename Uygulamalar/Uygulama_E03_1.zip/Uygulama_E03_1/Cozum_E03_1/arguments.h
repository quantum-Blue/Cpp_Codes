#ifndef __ARGUMENTS_H__
#define __ARGUMENTS_H__

#include <iostream>

using std::string;

class CommandLineArgsClass {
public:
	static const int GERCEK_GEREKLI_PARAMETRE_SAYISI{ 3 };
	static const int GEREKLI_PARAMETRE_SAYISI{ GERCEK_GEREKLI_PARAMETRE_SAYISI + 1 };

	inline static const string PROGRAM_KULLANIM_BILGISI_STR = "Kullanim: e301 [MAX_X] [MAX_Y] [MAX_Z]";

	static const int MAX_X_PARAMETRE_INDEKSI{ 1 };
	static const int MAX_Y_PARAMETRE_INDEKSI{ 2 };
	static const int MAX_Z_PARAMETRE_INDEKSI{ 3 };
};

#endif
