// Nokta Sınıfının Uygulanması
// Point sınıfının üye fonksiyonlarının tanımları
// Point sınıfı my_lib ad alanında tanımlanmıştır

#include <iostream>	    // cout için
#include "Point.h"		// Başlık dosyasının adı, Point bildirimi

using std::cout;
using std::endl;


namespace my_lib {

	//int Point::MAX_x = Point::DEFAULT_MAX_X; // Varsayılan değerler, ihtiyaca göre değiştirilebilir
	//int Point::MAX_y = Point::DEFAULT_MAX_Y;
	//int Point::MAX_z = Point::DEFAULT_MAX_Z;

// ***** Üye Fonksiyonların Gövdeleri *****

// Noktaları hareket ettiren bir fonksiyon
	bool Point::move(int new_x, int new_y, int new_z)
	{
		if (new_x >= MIN_X && new_x <= MAX_x)
			m_x = new_x;				// x koordinatına yeni değer atar
		else
		{
			cout << "Hatalı x değeri. Olması gereken aralık:" << MIN_X << " - " << MAX_x << " Girilen:" << new_x << endl;
			return false;
		}

		if (new_y >= MIN_Y && new_y <= MAX_y)
			m_y = new_y;				// y koordinatına yeni değer atar
		else
		{
			cout << "Hatalı y değeri. Olması gereken aralık:" << MIN_Y << " - " << MAX_y << " Girilen:" << new_y << endl;
			return false;
		}


		if (new_z >= MIN_Z && new_z <= MAX_z)
			m_z = new_z;				// z koordinatına yeni değer atar
		else
		{
			cout << "Hatalı z değeri. Olması gereken aralık:" << MIN_Z << " - " << MAX_z << " Girilen:" << new_z << endl;
			return false;
		}

		return true;
	}

	double Point::calculateDistanceTo(const Point& otherpoint) const
	{
		return std::sqrt(std::pow(otherpoint.getX() - m_x, 2) + std::pow(otherpoint.getY() - m_y, 2) + std::pow(otherpoint.getZ() - m_z, 2));
	}

	// Koordinatları ekranda yazdırmak için bir fonksiyon
	void Point::print() const
	{
		std::cout << "MIN_X = " << MIN_X << ", MIN_Y = " << MIN_Y << ", MIN_Z = " << MIN_Z << std::endl;
		std::cout << "MAX_x = " << MAX_x << ", MAX_y = " << MAX_y << ", MAX_Z = " << MAX_z << std::endl;
		std::cout << "X = " << m_x << ", Y = " << m_y << ", Z = " << m_z << std::endl;
	}
}
