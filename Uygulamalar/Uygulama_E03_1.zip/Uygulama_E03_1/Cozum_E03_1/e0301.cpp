﻿// e0301.cpp : Bu dosya 'main' işlevi içeriyor. Program yürütme orada başlayıp biter.
//
#include "error.h"
#include "arguments.h"
#include "Point.h"
#include <iostream>
#include <string>

using std::cout;
using std::endl;

int main(int argc, char* argv[])
{
	if (argc != CommandLineArgsClass::GEREKLI_PARAMETRE_SAYISI)
	{
		cout << "Gerekli parametre sayisi:" << CommandLineArgsClass::GEREKLI_PARAMETRE_SAYISI << endl;
		cout << "Girilen parametre sayisi:" << argc << endl;
		cout << CommandLineArgsClass::PROGRAM_KULLANIM_BILGISI_STR << endl;
		exit(YANLIS_PARAMETRE_SAYISI_HATASI);
	}
	else
	{
		cout << "argc:" << argc << endl;
		for (int i = 0; i < argc; i++)
			cout << i << ":" << argv[i] << endl;
		
		try {
			my_lib::Point::initializeMAX(std::stoi(argv[CommandLineArgsClass::MAX_X_PARAMETRE_INDEKSI]), std::stoi(argv[CommandLineArgsClass::MAX_Y_PARAMETRE_INDEKSI]), std::stoi(argv[CommandLineArgsClass::MAX_Z_PARAMETRE_INDEKSI]));
		}
		catch (const std::invalid_argument& e) {
			std::cerr << "Geçersiz argüman: " << e.what() << '\n';
			cout << CommandLineArgsClass::PROGRAM_KULLANIM_BILGISI_STR << endl;
			exit(GECERSIZ_ARGUMAN_HATASI);
		}
		catch (const std::out_of_range& e) {
			std::cerr << "Dışında: " << e.what() << '\n';
			cout << CommandLineArgsClass::PROGRAM_KULLANIM_BILGISI_STR << endl;
			exit(PARAMETRE_DEGER_ARALIGI_HATASI);
		}
	}	
	
	my_lib::Point point1;
	point1.print();
	cout << endl;

	my_lib::Point *point2 = new my_lib::Point;
	point2->print();
	cout << endl;

	if (point1.move(20, 40, 30) == false)
	{
		delete point2;
		exit(NOKTA_ICIN_GECERSIZ_DEGER_ARALIGI_HATASI);
	}

	point1.print();
	cout << endl;

	if (point2->isOnOrigin())
	{
		if (point2->move(25, 30, 50) == false)
		{
			delete point2;
			exit(NOKTA_ICIN_GECERSIZ_DEGER_ARALIGI_HATASI);
		}
	}

	my_lib::Point pointZero;
	cout << "Point1 nesnesinin orjine olan uzakligi:" << point1.calculateDistanceTo(pointZero) << endl;

	cout << "Point1 nesnesinin Point2 nesnesine olan uzakligi:" << point1.calculateDistanceTo(*point2) << endl;

	delete point2;
	return 0;
}
