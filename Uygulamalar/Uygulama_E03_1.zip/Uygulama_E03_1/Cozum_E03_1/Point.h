#ifndef __POINT_H__
#define __POINT_H__

namespace my_lib
{
	class Point {					// Point Sınıfı Bildirimi

	public:
		bool move(int new_x = MIN_X, int new_y = MIN_Y, int new_z = MIN_Z);		// Noktaları hareket ettiren fonksiyon
		void print() const;					// Koordinatları ekranda yazdırır
		double calculateDistanceTo(const Point& otherpoint) const; // Başka bir noktaya olan mesafeyi hesaplar

		static void initializeMAX(int maxX, int maxY, int maxZ) { // Maksimum değerleri başlatır
			MAX_x = maxX;
			MAX_y = maxY;
			MAX_z = maxZ;
		}

		// Getter'lar:
		int getX() const { return m_x; }         // x koordinatı için erişim sağlar
		int getY() const { return m_y; }         // y koordinatı için erişim sağlar
		int getZ() const { return m_z; }         // z koordinatı için erişim sağlar

		bool isOnOrigin() const		   // Nokta orijinde mi (0,0,0)?
		{
			return (m_x == 0) && (m_y == 0) && (m_z == 0);
		}

		// Koordinatları sıfırlar
		void resetCoordinates()
		{
			m_x = MIN_X;
			m_y = MIN_Y;
			m_z = MIN_Z;
		}

	private:
		// x, y ve z'nin limitleri
		// Sabitler genellikle statik üyeler olarak tanımlanır! (Statik üyelere bakınız)
		static const int MIN_X{ 0 };
		static const int MIN_Y{ 0 };
		static const int MIN_Z{ 0 };

		static const int DEFAULT_MAX_X{ 100 };
		static const int DEFAULT_MAX_Y{ 200 };
		static const int DEFAULT_MAX_Z{ 300 };

		inline static int MAX_x{ DEFAULT_MAX_X };
		inline static int MAX_y{ DEFAULT_MAX_Y };
		inline static int MAX_z{ DEFAULT_MAX_Z };

		int m_x{ MIN_X }, m_y{ MIN_Y }, m_z{ MIN_Z };	// Özellikler: x, y ve z koordinatları. Başlangıç değerleri: 0, 0, 0
	};

	// Statik değişkenlerin başlangıç değerleri (inline olduğu için gerek yok.)
	//int Point::MAX_X = DEFAULT_MAX_X;
	//int Point::MAX_y = DEFAULT_MAX_Y;
	//int Point::MAX_z = DEFAULT_MAX_Z;
}

#endif
