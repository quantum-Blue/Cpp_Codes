﻿#define _CRT_SECURE_NO_WARNINGS 1

#include <iostream>
#include <cstring>
#include <stdexcept>

#define MAX_INPUT_SIZE 5000


class IzuKatar {
private:
    size_t m_boyut;
    char* m_icerik;

public:

    // Varsayılan kurucu
    IzuKatar() : m_boyut(0), m_icerik(new char[1]) {
        m_icerik[0] = '\0';  // Boş katar olarak başlat
    }

    IzuKatar(const char* girisVerisi) {
        m_boyut = std::strlen(girisVerisi);
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, girisVerisi);
    }

    IzuKatar(const IzuKatar& diger) {
        m_boyut = diger.m_boyut;
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, diger.m_icerik);
    }

    ~IzuKatar() {
        delete[] m_icerik;
    }

    IzuKatar& operator=(const IzuKatar& diger) {
        if (this != &diger) {
            delete[] m_icerik;
            m_boyut = diger.m_boyut;
            m_icerik = new char[m_boyut + 1];
            std::strcpy(m_icerik, diger.m_icerik);
        }
        return *this;
    }

    IzuKatar operator+(const IzuKatar& diger) const {
        size_t yeni_boyut = m_boyut + diger.m_boyut;
        char* yeni_icerik = new char[yeni_boyut + 1];
        std::strcpy(yeni_icerik, m_icerik);
        std::strcat(yeni_icerik, diger.m_icerik);
        IzuKatar sonuc(yeni_icerik);
        delete[] yeni_icerik;
        return sonuc;
    }

    bool operator==(const IzuKatar& diger) const {
        return std::strcmp(m_icerik, diger.m_icerik) == 0;
    }

    bool operator!=(const IzuKatar& diger) const {
        return !(*this == diger);
    }

    bool operator<(const IzuKatar& diger) const {
        return std::strcmp(m_icerik, diger.m_icerik) < 0;
    }

    bool operator>(const IzuKatar& diger) const {
        return std::strcmp(m_icerik, diger.m_icerik) > 0;
    }

    bool operator<=(const IzuKatar& diger) const {
        return std::strcmp(m_icerik, diger.m_icerik) <= 0;
    }

    bool operator>=(const IzuKatar& diger) const {
        return std::strcmp(m_icerik, diger.m_icerik) >= 0;
    }

    char& operator[](size_t indeks) {
        if (indeks >= m_boyut) {
            throw std::out_of_range("İndeks sınır dışında");
        }
        return m_icerik[indeks];
    }

    const char& operator[](size_t indeks) const {
        if (indeks >= m_boyut) {
            throw std::out_of_range("İndeks sınır dışında");
        }
        return m_icerik[indeks];
    }

    friend std::ostream& operator<<(std::ostream& os, const IzuKatar& katar) {
        os << katar.m_icerik;
        return os;
    }

    friend std::istream& operator>>(std::istream& is, IzuKatar& katar) {
        char buffer[MAX_INPUT_SIZE];
        is.getline(buffer, MAX_INPUT_SIZE);
        katar.setIcerik(buffer);
        return is;
    }

    void yazdir() const {
        std::cout << m_icerik << " Uzunluk: " << m_boyut << std::endl;
    }

    void setIcerik(const char* yeniIcerik) {
        delete[] m_icerik;
        m_boyut = std::strlen(yeniIcerik);
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, yeniIcerik);
    }
};


int main() {
    // Katarlar oluşturuluyor
    IzuKatar k1("Merhaba"), k2("BIM108"), k3;

    // k1 ve k2 yazdırılıyor
    std::cout << "k1: " << k1 << std::endl;
    std::cout << "k2: " << k2 << std::endl;

    // Katarlar karşılaştırılıyor
    if (k1 == k2) {
        std::cout << "k1 ve k2 aynı." << std::endl;
    }
    else {
        std::cout << "k1 ve k2 farklı." << std::endl;
    }

    // k1 ve k2'nin büyüklük karşılaştırması
    if (k1 < k2) {
        std::cout << "k1 k2'den küçük." << std::endl;
    }
    else if (k1 > k2) {
        std::cout << "k1 k2'den büyük." << std::endl;
    }

    // k1 ve k2'nin büyüklük veya eşitlik karşılaştırması
    if (k1 <= k2) {
        std::cout << "k1 k2'den küçük veya eşit." << std::endl;
    }
    if (k1 >= k2) {
        std::cout << "k1 k2'den büyük veya eşit." << std::endl;
    }

    // Toplama operatörü kullanımı
    k3 = k1 + k2;
    std::cout << "k1 + k2: " << k3 << std::endl;

    // Atama operatörü kullanımı
    k3 = k1;
    std::cout << "k3 = k1: " << k3 << std::endl;

    // İndeksleme operatörü kullanımı
    try {
        std::cout << "k1'in ilk karakteri: " << k1[0] << std::endl;
        k1[0] = 'h';  // k1'in ilk karakterini değiştir
        std::cout << "k1'in yeni hali: " << k1 << std::endl;
    }
    catch (const std::out_of_range& e) {
        std::cerr << "Hata: " << e.what() << std::endl;
    }

    // Akış operatörleri ile kullanıcıdan veri alma
    std::cout << "Yeni katar giriniz: ";
    std::cin >> k3;
    std::cout << "Girilen katar: " << k3 << std::endl;

    return 0;
}
