#define _CRT_SECURE_NO_WARNINGS 1

#include <iostream>
#include <cstring>
#include <stdexcept>


class IzuKatar {
private:
    size_t m_boyut;
    char* m_icerik;

public:


    IzuKatar(const char* girisVerisi) {
        m_boyut = std::strlen(girisVerisi);
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, girisVerisi);
    }

    IzuKatar(const IzuKatar& diger) {
        m_boyut = diger.m_boyut;
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, diger.m_icerik);
    }

    ~IzuKatar() {
        delete[] m_icerik;
    }

    IzuKatar& operator=(const IzuKatar& diger) {

    }

    IzuKatar operator+(const IzuKatar& diger) const {

    }

    bool operator==(const IzuKatar& diger) const {

    }

    bool operator!=(const IzuKatar& diger) const {

    }

    bool operator<(const IzuKatar& diger) const {

    }

    bool operator>(const IzuKatar& diger) const {

    }

    bool operator<=(const IzuKatar& diger) const {

    }

    bool operator>=(const IzuKatar& diger) const {

    }

    char& operator[](size_t indeks) {
    
    }

    const char& operator[](size_t indeks) const {
    
    }

    friend std::ostream& operator<<(std::ostream& os, const IzuKatar& katar) {
    
    }

    friend std::istream& operator>>(std::istream& is, IzuKatar& katar) {
    
    }

    void yazdir() const {
        std::cout << m_icerik << " Uzunluk: " << m_boyut << std::endl;
    }

    void setIcerik(const char* yeniIcerik) {
        delete[] m_icerik;
        m_boyut = std::strlen(yeniIcerik);
        m_icerik = new char[m_boyut + 1];
        std::strcpy(m_icerik, yeniIcerik);
    }
};


int main() {
 
}
