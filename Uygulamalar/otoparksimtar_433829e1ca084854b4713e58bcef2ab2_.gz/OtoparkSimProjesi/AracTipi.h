#pragma once
#include <map>
#include <string>
// Araç türleri için enum
enum class AracTipi { Otomobil, Minibus, Otobus, Motosiklet };


