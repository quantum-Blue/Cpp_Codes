#pragma once
#include <map>
#include "AracTipi.h"

class Otopark
{
protected:
    std::map<AracTipi, std::map<int, double>> ucretler;
    int ucretsizDakika;
    std::string isim;
    std::map<std::string, double> plakaHasilat;
    double toplamHasilat;
public:
    Otopark(std::string ad, int ucretsizMin) : isim(ad), ucretsizDakika(ucretsizMin), toplamHasilat(0) {}
    virtual double ucretHesapla(AracTipi tip, int sure, const std::string& plaka);
    void raporOlustur();
};

