#include <map>
#include "AracTipi.h"

std::map<AracTipi, std::string> aracTipiIsimleri = {
    {AracTipi::Otomobil, "Otomobil"},
    {AracTipi::Minibus, "Minibüs"},
    {AracTipi::Otobus, "Otobüs"},
    {AracTipi::Motosiklet, "Motosiklet"}
};

