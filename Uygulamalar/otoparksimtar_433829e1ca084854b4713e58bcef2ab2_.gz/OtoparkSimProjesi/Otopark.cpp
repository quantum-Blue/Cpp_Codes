#include <fstream>
#include "Otopark.h"


// Ücret hesaplama ve raporlama işlemleri
double Otopark::ucretHesapla(AracTipi tip, int sure, const std::string& plaka) {
    sure -= ucretsizDakika;
    if (sure <= 0) return 0.0;

    double ucret = 0;
    for (auto& tarife : ucretler[tip]) {
        if (sure <= tarife.first) {
            ucret = tarife.second;
            break;
        }
    }
    if (ucret == 0) ucret = ucretler[tip].rbegin()->second;

    plakaHasilat[plaka] += ucret;
    toplamHasilat += ucret;
    return ucret;
}

void Otopark::raporOlustur() {
    std::ofstream dosya(isim + ".txt");
    for (const auto& kayit : plakaHasilat) {
        dosya << "Plaka: " << kayit.first << ", Toplam Ücret: " << kayit.second << " TL\n";
    }
    dosya << "Toplam Hasilat: " << toplamHasilat << " TL\n";
    dosya.close();
}
