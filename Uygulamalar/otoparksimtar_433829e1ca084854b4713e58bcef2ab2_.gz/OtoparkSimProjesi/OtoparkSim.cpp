// OtoparkSim.cpp : Bu dosya 'main' işlevi içeriyor. Program yürütme orada başlayıp biter.
//

#include <iostream>

#include "Otopark.h"

#include "BolgeBirIkiOtopark.h"


// Rastgele plakalar ve park süreleri üretme
std::string rastgelePlaka() {
    std::string plaka = "";
    plaka += "34";
    plaka += char('A' + rand() % 26);
    plaka += char('A' + rand() % 26);
    plaka += std::to_string(rand() % 10);
    plaka += std::to_string(rand() % 10);
    plaka += std::to_string(rand() % 10);
    return plaka;
}

// Rastgele park etkinliklerini simüle etme fonksiyonu
void parkSimulasyonu(Otopark& park) {
    srand(time(NULL));
    AracTipi tipler[4] = { AracTipi::Otomobil, AracTipi::Minibus, AracTipi::Otobus, AracTipi::Motosiklet };

    for (int i = 0; i < 10; i++) { // 10 rastgele park etkinliği simüle et
        AracTipi tip = tipler[rand() % 4];
        std::string plaka = rastgelePlaka();
        int sure = (rand() % 1440) + 1; // 1'den 1440'a kadar süre (dakika cinsinden 24 saat)

        double ucret = park.ucretHesapla(tip, sure, plaka);
        std::cout << "Plaka: " << plaka << " - Araç tipi: " << aracTipiIsimleri[tip] << " için " << sure << " dakika park edildi. Ücret: " << ucret << " TL" << std::endl;
    }
    park.raporOlustur();
}

int main()
{
    BolgeBirIkiOtopark bolge12("Bolge1_2_Otopark");
    parkSimulasyonu(bolge12);
    return 0;
}



