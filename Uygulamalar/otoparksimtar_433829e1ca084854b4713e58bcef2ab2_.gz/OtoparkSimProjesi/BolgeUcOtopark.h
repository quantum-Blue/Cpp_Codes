#pragma once
#include "BolgeBirIkiOtopark.h"
class BolgeUcOtopark : public BolgeBirIkiOtopark
{
public:
    BolgeUcOtopark(std::string ad) : BolgeBirIkiOtopark(ad, 15) {
        for (auto& arac : ucretler) {
            for (auto& tarife : arac.second) {
                tarife.second *= 0.7; // %30 indirim uygula
            }
        }
    }
};


