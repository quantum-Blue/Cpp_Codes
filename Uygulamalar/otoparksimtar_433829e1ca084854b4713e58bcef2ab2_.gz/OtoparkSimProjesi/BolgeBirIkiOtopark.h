#pragma once
#include "Otopark.h"
class BolgeBirIkiOtopark : public Otopark
{
public:
    BolgeBirIkiOtopark(std::string ad) : Otopark(ad, 5) {
        ucretler[AracTipi::Otomobil] = { {60, 52}, {120, 66}, {240, 73}, {480, 100}, {720, 134}, {1440, 202} };
        ucretler[AracTipi::Minibus] = { {60, 104}, {120, 132}, {240, 146}, {480, 200}, {720, 268}, {1440, 400} };
        ucretler[AracTipi::Otobus] = { {60, 156}, {120, 198}, {240, 219}, {480, 300}, {720, 402}, {1440, 600} };
        ucretler[AracTipi::Motosiklet] = { {60, 26}, {120, 33}, {240, 36.5}, {480, 50}, {720, 67}, {1440, 100} };
    }
};


