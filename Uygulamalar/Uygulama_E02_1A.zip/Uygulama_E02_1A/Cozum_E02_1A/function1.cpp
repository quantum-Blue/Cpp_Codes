// function1.cpp �rne�i i�in e02_1a.zip
// function1 fonksiyonunun tan�m�n� i�erir

#include <iostream>				// Girdi ve ��kt� i�in standart header dosyas�
// import <iostream>;               // C++20'den itibaren (mod�l)
// import std;                      // C++23'ten itibaren (mod�l)

// function1, giri� parametresini 0.1 art�r�r
double function1(double input) {
	std::cout << "Fonksiyon 1 calisiyor \n";
	return input + 0.1;
}
