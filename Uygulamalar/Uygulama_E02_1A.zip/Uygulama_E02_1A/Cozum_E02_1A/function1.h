// e02_1a.zip �rne�i i�in function1.h
// function1 fonksiyonunun ba�l�k dosyas� (bildirimi)
// function1, giri� parametresini 0.1 art�r�r
double function1(double);   // Bildirim
